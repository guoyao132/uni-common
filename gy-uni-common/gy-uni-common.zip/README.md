﻿## init
```javascript
app.use(gyUniCommon);
```
